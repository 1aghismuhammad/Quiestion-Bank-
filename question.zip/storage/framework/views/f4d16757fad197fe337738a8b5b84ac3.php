<?php $__env->startSection('title', 'Lengkapi Profil'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" style="max-width: 560px; margin: 24px auto;">
        <p class="muted">LANGKAH TERAKHIR</p>
        <h1>Lengkapi nomor WhatsApp</h1>
        <p class="muted">
            Nomor telepon wajib diisi sebelum Anda dapat mengakses dashboard.
            Format Indonesia akan otomatis dinormalisasi ke +62.
        </p>

        <form method="POST" action="<?php echo e(route('profile.setup.store')); ?>">
            <?php echo csrf_field(); ?>

            <label class="label" for="phone_number">Nomor telepon</label>
            <input
                class="input"
                id="phone_number"
                name="phone_number"
                type="tel"
                value="<?php echo e(old('phone_number', auth()->user()->phone_number)); ?>"
                placeholder="081234567890"
                required
                autofocus
            >

            <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error-text"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button class="button" style="margin-top: 20px;" type="submit">
                Simpan dan lanjutkan
            </button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\dingcoding\question\resources\views/profile/setup.blade.php ENDPATH**/ ?>