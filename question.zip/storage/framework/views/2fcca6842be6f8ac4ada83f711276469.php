<?php $__env->startSection('title', 'AI Question Bank'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" style="max-width: 720px; margin: 48px auto; text-align: center; padding: 48px;">
        <p class="muted">AI QUESTION BANK SAAS</p>
        <h1>Buat bank soal dari materi pembelajaran</h1>
        <p class="muted">
            Masuk menggunakan akun Google untuk mengakses dashboard dan melengkapi profil.
        </p>

        <?php if(auth()->guard()->check()): ?>
            <a class="button" href="<?php echo e(route('dashboard')); ?>">Buka Dashboard</a>
        <?php else: ?>
            <a class="button" href="<?php echo e(route('auth.google.redirect')); ?>">Login dengan Google</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\dingcoding\question\resources\views/home.blade.php ENDPATH**/ ?>