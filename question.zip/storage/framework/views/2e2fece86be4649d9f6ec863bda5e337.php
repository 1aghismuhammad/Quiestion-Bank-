<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'AI Question Bank'); ?></title>
    <style>
        :root {
            color-scheme: light;
            font-family: Inter, ui-sans-serif, system-ui, sans-serif;
            color: #172033;
            background: #f4f7fb;
        }

        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; }
        a { color: inherit; }
        .container { width: min(1080px, calc(100% - 32px)); margin: 0 auto; }
        .nav { background: #ffffff; border-bottom: 1px solid #dce3ee; }
        .nav-inner { min-height: 64px; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
        .brand { font-size: 18px; font-weight: 750; text-decoration: none; }
        .nav-actions { display: flex; align-items: center; gap: 12px; }
        .page { padding: 40px 0; }
        .card { background: #ffffff; border: 1px solid #dce3ee; border-radius: 14px; padding: 24px; }
        .grid { display: grid; gap: 16px; grid-template-columns: repeat(auto-fit, minmax(210px, 1fr)); }
        .button { display: inline-flex; align-items: center; justify-content: center; min-height: 42px; padding: 0 18px; border: 0; border-radius: 9px; background: #2356d8; color: #ffffff; font-weight: 700; text-decoration: none; cursor: pointer; }
        .button-secondary { background: #e9eef8; color: #172033; }
        .muted { color: #667085; }
        .label { display: block; margin-bottom: 8px; font-size: 14px; font-weight: 700; }
        .input { width: 100%; min-height: 44px; border: 1px solid #bac5d6; border-radius: 9px; padding: 10px 12px; font: inherit; }
        .alert { margin-bottom: 20px; border-radius: 9px; padding: 12px 14px; }
        .alert-success { color: #155e3b; background: #e8f8ef; }
        .alert-error { color: #9f2424; background: #fdecec; }
        .error-text { margin-top: 6px; color: #b42318; font-size: 14px; }
        .stat { font-size: 34px; font-weight: 800; margin: 6px 0 0; }
        .placeholder { min-height: 120px; display: flex; flex-direction: column; justify-content: space-between; }
        .status { display: inline-block; padding: 4px 10px; border-radius: 999px; background: #e8f8ef; color: #155e3b; font-size: 13px; font-weight: 700; }
        h1, h2, p { margin-top: 0; }
    </style>
</head>
<body>
    <nav class="nav">
        <div class="container nav-inner">
            <a class="brand" href="<?php echo e(route('home')); ?>">AI Question Bank</a>

            <?php if(auth()->guard()->check()): ?>
                <div class="nav-actions">
                    <span class="muted"><?php echo e(auth()->user()->name); ?></span>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="button button-secondary" type="submit">Logout</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </nav>

    <main class="container page">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH D:\dingcoding\question\resources\views/layouts/app.blade.php ENDPATH**/ ?>