<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <p class="muted">ADMIN DASHBOARD</p>
    <h1>Ringkasan pengguna</h1>
    <p class="muted">Monitoring detail belum termasuk dalam Phase 1.</p>

    <div class="grid" style="margin-top: 24px;">
        <div class="card">
            <span class="muted">Total User</span>
            <p class="stat"><?php echo e($totalUsers); ?></p>
        </div>

        <div class="card">
            <span class="muted">Total Admin</span>
            <p class="stat"><?php echo e($totalAdmins); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\dingcoding\question\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>