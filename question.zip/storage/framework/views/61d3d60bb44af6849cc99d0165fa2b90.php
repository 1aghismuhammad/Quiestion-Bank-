<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card" style="margin-bottom: 20px;">
        <p class="muted">USER DASHBOARD</p>
        <h1>Selamat datang, <?php echo e($user->name); ?></h1>
        <p><strong>Email:</strong> <?php echo e($user->email); ?></p>
        <p>
            <strong>Status akun:</strong>
            <span class="status"><?php echo e(strtoupper($user->status->value)); ?></span>
        </p>
    </div>

    <h2>Menu</h2>
    <div class="grid">
        <?php $__currentLoopData = ['Generate Question', 'Question Bank', 'History', 'Subscription']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card placeholder">
                <strong><?php echo e($menu); ?></strong>
                <span class="muted">Segera hadir pada phase berikutnya.</span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\dingcoding\question\resources\views/dashboard.blade.php ENDPATH**/ ?>